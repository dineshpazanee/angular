import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.scss']
})
export class TableComponent { title = 'Highlight Table Row on Hover';
 
ngOnInit () {  }

// CREATE A JSON ARRAY.
employees: any [] = [
  { 'id': '001', 'name': 'Alpha', 'joinDate': '05/17/2015', 'age': 37 },
  { 'id': '002', 'name': 'Bravo', 'joinDate': '03/25/2016', 'age': 27 },
  { 'id': '003', 'name': 'Charlie', 'joinDate': '09/11/2015', 'age': 29 },
  { 'id': '004', 'name': 'Delta', 'joinDate': '01/07/2016', 'age': 19 },
  { 'id': '005', 'name': 'Echo', 'joinDate': '03/09/2014', 'age': 32 }
];

public id:any;

public highlightRow(emp) {
  this.id = emp.id;
}

setClickedRow = function(index){
  this.selectedRow = index;
}

}