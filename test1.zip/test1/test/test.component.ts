import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-test',
  templateUrl: './test.component.html',
  styleUrls: ['./test.component.scss']
})
export class TestComponent implements OnInit {

  constructor() { }

  color: String;

  ngOnInit() {
  }

  disable = false;

  list = [1, 2, 3, 4, 5, 6, 7, 8, 9];

  textcolor = "text-color";

  loadColor = "success";

  private lines = [ "line 1", "line 2", "line 3","line 4", "line 5", "line 6", "line 7" ];
  private styles = { 4: "red", 5: "green" };

  test(l: any, i : any){
    if(this.list[i] == l)
      console.log(this.list[i] +" : "+l);
      this.list[i] = 20;
      this.textcolor = "text-update";
      this.disable = true;
  }

  toggleClick(clickedItem: any): void {

  }

}
